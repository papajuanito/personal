<?php
/**
 * Set the application environment here. It is 'local' by default.
 */

return 'local';

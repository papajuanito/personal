@extends('layouts/master')

@section('content')
<main id="view-work" role="main">
    <div class="contain with-icon">
        <img src="{{ asset('img/work-window-dark.png') }}" />
        <h2>[<b>work</b>] Sites & apps</h2>
        <ul class="work-list">
            @if(Agent::isMobile())
                <li class="work-item big" style="background: url({{ asset('img/thumbnails/thumb-playstation.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>playstation</b>
                                <p>Nación Play</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item medium" style="background: url({{ asset('img/thumbnails/thumb-emerge.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>lexus</b>
                                <p>Car Model Configurator</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item small last" style="background: url({{ asset('img/thumbnails/thumb-herbal.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>copa airlines</b>
                                <p>Descubre Panama con Copa</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item big" style="background: url({{ asset('img/thumbnails/thumb-lexus.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>playstation</b>
                                <p>Nación Play</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item medium" style="background: url({{ asset('img/thumbnails/thumb-destinations.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>lexus</b>
                                <p>Car Model Configurator</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item small last" style="background: url({{ asset('img/thumbnails/thumb-heart.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>copa airlines</b>
                                <p>Descubre Panama con Copa</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item big" style="background: url({{ asset('img/thumbnails/thumb-panama.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>playstation</b>
                                <p>Nación Play</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item medium" style="background: url({{ asset('img/thumbnails/thumb-pledge.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>lexus</b>
                                <p>Car Model Configurator</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item small last" style="background: url({{ asset('img/thumbnails/thumb-jdch.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>copa airlines</b>
                                <p>Descubre Panama con Copa</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item big last" style="background: url({{ asset('img/thumbnails/thumb-discovery.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>playstation</b>
                                <p>Nación Play</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item medium" style="background: url({{ asset('img/thumbnails/thumb-esposible.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>lexus</b>
                                <p>Car Model Configurator</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item small last" style="background: url({{ asset('img/thumbnails/thumb-gustazos.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>copa airlines</b>
                                <p>Descubre Panama con Copa</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
            @else
                <li class="work-item big" style="background: url({{ asset('img/thumbnails/thumb-playstation.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>playstation</b>
                                <p>Nación Play</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item medium" style="background: url({{ asset('img/thumbnails/thumb-emerge.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>lexus</b>
                                <p>Car Model Configurator</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item small last" style="background: url({{ asset('img/thumbnails/thumb-herbal.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>copa airlines</b>
                                <p>Descubre Panama con Copa</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item small" style="background: url({{ asset('img/thumbnails/thumb-heart.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>copa airlines</b>
                                <p>Descubre Panama con Copa</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item medium" style="background: url({{ asset('img/thumbnails/thumb-destinations.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>lexus</b>
                                <p>Car Model Configurator</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item big last" style="background: url({{ asset('img/thumbnails/thumb-lexus.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>playstation</b>
                                <p>Nación Play</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item big" style="background: url({{ asset('img/thumbnails/thumb-panama.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>playstation</b>
                                <p>Nación Play</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item medium" style="background: url({{ asset('img/thumbnails/thumb-pledge.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>lexus</b>
                                <p>Car Model Configurator</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item small last" style="background: url({{ asset('img/thumbnails/thumb-jdch.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>copa airlines</b>
                                <p>Descubre Panama con Copa</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item small" style="background: url({{ asset('img/thumbnails/thumb-gustazos.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>copa airlines</b>
                                <p>Descubre Panama con Copa</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item medium" style="background: url({{ asset('img/thumbnails/thumb-esposible.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>lexus</b>
                                <p>Car Model Configurator</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="work-item big last" style="background: url({{ asset('img/thumbnails/thumb-discovery.png')}} ); background-size: cover; background-position: center;">
                    <div class="circle">
                        <div class="work-sum">
                            <div class="content big">
                                <b>playstation</b>
                                <p>Nación Play</p>
                                <a href="#">View Project</a>
                            </div>
                        </div>
                    </div>
                </li>
            @endif
        </ul>
    </div>
</main>
@stop

<footer id="footer">
    <div class="contain">
        <div class="footer-nav">
            <!--nav>
                <a href="#">About us</a>
                <a href="#">Contact us</a>
                <a href="#">Press</a>
            </nav-->
        </div>
</footer>

<footer id="footer">
    <div class="contain">
        <div class="footer-nav">
            <nav>
                <a target="_blank" href="https://www.codeeval.com/public/6b52b8cb9a816f667cf958d75b33405713269d47">CodeEval</a>
                <a target="_blank" href="http://www.linkedin.com/in/javelazquez">LinkedIn</a>
                <a target="_blank" href="https://github.com/papajuanito">Github</a>
                <a class="no-border" target="_blank" href="{{ asset('files/resume.pdf') }}">Resume</a>
                <img src="{{ asset('img/footer-logo.png') }}">
            </nav>

        </div>
</footer>

/*
 Main application module

 * Add routes with their respective module, one per route.
 * If the same module is needed in two views, include the class instance multiple times
*/


(function() {
  define(function(require) {
    var $, App, Index, routes;
    $ = require('jquery');
    Index = require('app/index');
    require('reveal');
    routes = {
      'index': Index
    };
    /*
     Class App
    */

    App = (function() {
      function App() {
        console.log('Main app module was built without side effects');
      }

      App.prototype.init = function() {
        var _this = this;
        return $(document).ready(function() {
          var module, route;
          _this.$body = $('body');
          _this.basePath = _this.$body.data('base');
          _this.assetsPath = _this.$body.data('assets');
          route = _this.$body.data('route');
          _this.foundation();
          if (typeof routes[route] === 'function') {
            module = new routes[route]();
            return module.init();
          }
        });
      };

      App.prototype.events = function() {
        var $window,
          _this = this;
        $window = $(window);
        return $window.on('scroll.main', function(e) {
          return window.requestAnimationFrame(function() {
            return _this.disableHover();
          });
        });
      };

      App.prototype.disableHover = function() {
        var timer,
          _this = this;
        clearTimeout(timer);
        if (!this.$body.hasClass('disable-hover')) {
          this.$body.addClass('disable-hover');
        }
        return timer = setTimeout(function() {
          return _this.$body.removeClass('disable-hover');
        }, 500);
      };

      App.prototype.foundation = function() {
        return $(document).foundation('reveal');
      };

      return App;

    })();
    return new App;
  });

}).call(this);

/*
 View: index
*/


(function() {
  define(function(require) {
    var Index;
    return Index = (function() {
      function Index() {}

      Index.prototype.init = function() {
        console.log('Home init');
        return this.events();
      };

      Index.prototype.events = function() {
        var $header, $hero, $window, fixedHeader,
          _this = this;
        $window = $(window);
        $header = $('#header');
        $hero = $("#home-hero");
        fixedHeader = function() {
          if ($window.scrollTop() > $hero.innerHeight() - $header.innerHeight()) {
            return $header.addClass('is-transparent');
          } else {
            return $header.removeClass('is-transparent');
          }
        };
        return $window.on('scroll.home', function(e) {
          return window.requestAnimationFrame(fixedHeader);
        });
      };

      return Index;

    })();
  });

}).call(this);

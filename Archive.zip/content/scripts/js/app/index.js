/*
 View: index
*/


(function() {
  define(function(require) {
    var Index;
    return Index = (function() {
      function Index() {}

      Index.prototype.init = function() {
        console.log('Home init');
        return this.events();
      };

      Index.prototype.events = function() {
        var $assets, $current, $header, $hero, $images, $window, fixedHeader, preload,
          _this = this;
        $window = $(window);
        $header = $('#header');
        $assets = $('body').data('assets');
        $hero = $("#home-hero");
        $current = 1;
        $images = [];
        $('.profile-links a').addClass('pop');
        preload = function() {
          var galleryInterval, i;
          i = 0;
          while (i < preload["arguments"].length) {
            $images[i] = new Image();
            $images[i].src = preload["arguments"][i];
            i++;
          }
          return galleryInterval = setInterval(function() {
            if ($current <= 2) {
              $current++;
            } else {
              $current = 1;
            }
            return $hero.css({
              background: "url('../img/header/header-" + $current + ".jpg') center 40px no-repeat",
              "background-size": "cover"
            });
          }, 4000);
        };
        if (!$hero.hasClass('mobile')) {
          console.log($hero.hasClass('mobile'));
          preload($assets + 'img/header/header-2.jpg', $assets + 'img/header/header-3.jpg');
        }
        fixedHeader = function() {
          if ($window.scrollTop() > $hero.innerHeight() - $header.innerHeight()) {
            return $header.addClass('is-transparent');
          } else {
            return $header.removeClass('is-transparent');
          }
        };
        return $window.on('scroll.home', function(e) {
          return window.requestAnimationFrame(fixedHeader);
        });
      };

      return Index;

    })();
  });

}).call(this);

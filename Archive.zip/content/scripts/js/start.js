(function() {
  define(function(require) {
    var $, app;
    $ = require('jquery');
    app = require('app/main');
    return $(document).ready(function() {
      return app.init();
    });
  });

}).call(this);
